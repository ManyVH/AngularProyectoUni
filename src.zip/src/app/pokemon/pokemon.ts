export interface Pokemon {
    nombre:String,
    hp:number
}
