import { Component, OnInit } from '@angular/core';
import { Pokemon } from './pokemon';

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.component.html',
  styleUrls: ['./pokemon.component.css']
})
export class PokemonComponent implements OnInit {
  listaPokemon: Pokemon[] = [{
    nombre: 'Charmander',
    hp: 500
  },{
    nombre: 'Bulbasaour',
    hp: 600
  },{
    nombre: 'Squirtle',
    hp: 800
  }]
  nombre ='';
  hp = 0;
  constructor() { }

  ngOnInit(): void {
  }
  pasarN(event: any){
      this.nombre = event.target.value+'';
  }
  pasarH(event: any){
      this.hp = Number.parseInt(event.target.value+'');
  }

  agregarPokimon(){
      this.listaPokemon.push({nombre:this.nombre,hp:this.hp});
  }
  limpiar(){
    this.listaPokemon = []
  }

}
